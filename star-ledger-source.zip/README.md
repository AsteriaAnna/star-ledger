# Star Ledger Duo / 星账双人版

Offline-first personal and paired ledger. Green/purple ownership modes, custodial savings, statement import, transfer reconciliation, refund accounting, local revision log and encrypted private GitHub repository synchronization.

The generated static app is in `dist/`. There is no server-side database or runtime dependency. Local browser data is not encrypted at rest. GitHub payloads and optionally remembered access tokens are encrypted with AES-GCM / PBKDF2; the passphrase is kept only in memory.

## Build

```sh
python3 v2/build.py
```

## Verification

```sh
node --test tests/accounting.cjs tests/sync.cjs
node tests/interface.cjs
```

The import test uses a generated XLSX fixture and the environment's xml-js package to emulate browser DOMParser. It is not part of the dependency-free runtime.

No real financial data, credentials, GitHub repository, deployed address, or platform-native installers are included. See `v2/使用说明.md` and `v2/发布说明.md` for user setup and outstanding device verification.
