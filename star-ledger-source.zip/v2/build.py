from pathlib import Path
import shutil
p=Path(__file__).resolve().parent
out=p.parent/'dist';out.mkdir(exist_ok=True)
html=(p/'index.html').read_text()
for marker,filename in [('STYLE','style.css'),('PARSER','parser.js'),('MODEL','model.js'),('STORAGE','storage.js'),('APP','app.js')]:
 text=(p/filename).read_text()
 assert '</script>' not in text
 html=html.replace('/* '+marker+' */',text)
(out/'index.html').write_text(html)
for filename in ['sw.js','manifest.webmanifest','icon.svg','icon-192.png','icon-512.png']:
 if (p/filename).exists():shutil.copy2(p/filename,out/filename)
(out/'.nojekyll').touch()
print('Static application assembled:',out)
